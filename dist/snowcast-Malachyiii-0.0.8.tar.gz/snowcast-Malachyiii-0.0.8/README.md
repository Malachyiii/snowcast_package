This is a package to help automate the pulling of Satellite Imagery and Tabular data for the Snowcast Snow Forecasting project
